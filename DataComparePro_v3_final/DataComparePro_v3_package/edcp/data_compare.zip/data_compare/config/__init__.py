# -*- coding: utf-8 -*-
"""data_compare.config – YAML config loader with hardcoded defaults."""
from data_compare.config.config_loader import load_config
__all__ = ["load_config"]
