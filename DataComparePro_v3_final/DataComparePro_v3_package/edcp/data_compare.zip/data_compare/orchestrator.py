# -*- coding: utf-8 -*-
"""
data_compare.orchestrator
──────────────────────────
Main pipeline controller – capability-based architecture.

Public API
----------
run_comparison(config_path=None)
    Load config, parse InputSheet, dispatch all active batches through the
    capability registry, write HTML + JSON summary, send email.

from data_compare.orchestrator import run_comparison
run_comparison("config/config.yaml")

PySpark
-------
spark.sparkContext.addPyFile("data_compare.zip")
from data_compare.orchestrator import run_comparison
run_comparison("/dbfs/mnt/config/config.yaml")
"""

from __future__ import annotations

import logging
import math
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

from data_compare.comparator.tolerance import build_tolerance_map
from data_compare.config.config_loader import load_config
from data_compare.context.run_context import make_context
from data_compare.loaders.file_loader import load_any_to_csv
from data_compare.registry.capability_registry import CapabilityRegistry, default_registry
from data_compare.reporting.html_report import write_final_html, send_email
from data_compare.reporting.json_audit import write_json_audit
from data_compare.reporting.report_builder import build_report
from data_compare.utils.helpers import (
    ensure_dir,
    normalized_colnames_mapping,
)
from data_compare.utils.logger import (
    banner,
    configure_logging,
    get_logger,
)
from data_compare.utils.validation import (
    extract_key_columns,
    parse_batch_row,
    validate_config_sheet,
)

logger = get_logger(__name__)

_LOG_LEVELS = {
    "DEBUG":   logging.DEBUG,
    "INFO":    logging.INFO,
    "WARNING": logging.WARNING,
    "ERROR":   logging.ERROR,
}


# ══════════════════════════════════════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _find_sheet_by_hint(
    xl: pd.ExcelFile, *hints: str, fallback_first: bool = True
) -> Optional[str]:
    names = xl.sheet_names
    lower = [n.lower() for n in names]
    for h in hints:
        for i, nm in enumerate(lower):
            if h.lower() in nm:
                return names[i]
    return names[0] if (names and fallback_first) else None


def _print_console_summary(summaries: List[Dict]) -> None:
    banner("RUN SUMMARY", "═")
    col_w = [4, 30, 10, 10, 12, 12, 10, 10, 8, 8, 7]
    hdr   = [
        "#", "Result Name", "TotalProd", "TotalDev",
        "Passed", "Failed", "Missing", "Extra",
        "DupP", "DupD", "Time",
    ]
    fmt = lambda row: "  │ ".join(
        str(v)[:col_w[i]].ljust(col_w[i]) for i, v in enumerate(row)
    )
    sep = "  ┼─".join("─" * w for w in col_w)
    logger.info("  " + fmt(hdr))
    logger.info("  " + sep)
    for i, s in enumerate(summaries, 1):
        err = "⚠ " if s.get("Error") else ""
        row = [
            i,
            err + s.get("ResultName", "")[:28],
            f"{s.get('TotalProd',0):,}",
            f"{s.get('TotalDev',0):,}",
            f"{s.get('MatchedPassed',0):,}",
            f"{s.get('MatchedFailed',0):,}",
            f"{s.get('MissingDev',0):,}",
            f"{s.get('ExtraDev',0):,}",
            f"{s.get('DuplicateProd',0):,}",
            f"{s.get('DuplicateDev',0):,}",
            f"{s.get('ElapsedSeconds',0):.1f}s",
        ]
        logger.info("  " + fmt(row))
    banner("END OF SUMMARY", "═")


def _context_to_summary(context: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
    """
    Extract the flat summary dict from a completed context.
    This dict is consumed by write_final_html() and write_json_audit().
    """
    cfg           = context.get("config", {})
    results       = context.get("results", {})
    schema_diff   = context.get("schema_diff_df")
    prod_df       = context.get("prod_df")
    dev_df        = context.get("dev_df")
    only_in_prod  = context.get("only_in_prod")
    only_in_dev   = context.get("only_in_dev")
    alert_triggered = context.get("alerts", {}).get("triggered", [])

    return {
        "ResultName":        cfg.get("result_name", ""),
        "ProdFile":          context.get("prod_name", ""),
        "DevFile":           context.get("dev_name",  ""),
        "TotalProd":         len(prod_df)   if prod_df is not None else 0,
        "TotalDev":          len(dev_df)    if dev_df  is not None else 0,
        "MatchedPassed":     results.get("matched_passed",  0),
        "MatchedFailed":     results.get("matched_failed",  0),
        "ExtraDev":          len(only_in_dev)  if only_in_dev  is not None else 0,
        "MissingDev":        len(only_in_prod) if only_in_prod is not None else 0,
        "DuplicateProd":     context.get("dup_count_prod", 0),
        "DuplicateDev":      context.get("dup_count_dev",  0),
        "UsedKeys":          context.get("existing_keys", []),
        "MissingKeyColumns": context.get("missing_keys",  []),
        "IgnoredFields":     sorted(context.get("ignore_set", set())),
        "ToleranceUsed":     context.get("tol_for_pair", {}),
        "ReportPath":        context.get("report_path", ""),
        "ElapsedSeconds":    round(elapsed, 2),
        "AlertsTriggered":   len(alert_triggered),
        "SchemaExtraCount":  int((schema_diff["Side"] == "Extra in Dev").sum())
                             if schema_diff is not None and not schema_diff.empty else 0,
        "SchemaMissingCount":int((schema_diff["Side"] == "Missing in Dev").sum())
                             if schema_diff is not None and not schema_diff.empty else 0,
    }


def _empty_error_summary(
    result_nm: str, prod_name: str, dev_name: str, exc: Exception
) -> Dict[str, Any]:
    return {
        "ResultName":        result_nm,
        "ProdFile":          prod_name,
        "DevFile":           dev_name,
        "TotalProd":         0, "TotalDev":        0,
        "MatchedPassed":     0, "MatchedFailed":   0,
        "ExtraDev":          0, "MissingDev":      0,
        "DuplicateProd":     0, "DuplicateDev":    0,
        "UsedKeys":          [], "MissingKeyColumns": [],
        "IgnoredFields":     [], "ToleranceUsed":  {},
        "ReportPath":        "",
        "ElapsedSeconds":    0.0,
        "AlertsTriggered":   0,
        "SchemaExtraCount":  0, "SchemaMissingCount": 0,
        "Error":             str(exc),
    }


# ══════════════════════════════════════════════════════════════════════════════
#  PUBLIC API
# ══════════════════════════════════════════════════════════════════════════════

def run_comparison(
    config_path: Optional[str] = None,
    registry: Optional[CapabilityRegistry] = None,
) -> List[Dict[str, Any]]:
    """
    Execute the full capability-based comparison pipeline.

    Parameters
    ----------
    config_path : str | None
        Path to a YAML config file.  None → hardcoded defaults in config_loader.
    registry : CapabilityRegistry | None
        Capability registry to use.  None → module-level default_registry.
        Pass a custom registry to override or extend capabilities.

    Returns
    -------
    list[dict]
        All batch summary dicts (including error entries for failed batches).
    """
    if registry is None:
        registry = default_registry

    cfg = load_config(config_path)

    level_str = str(cfg.get("log_level", "DEBUG")).upper()
    configure_logging(level=_LOG_LEVELS.get(level_str, logging.DEBUG))

    run_start = time.perf_counter()
    banner("DATA COMPARATOR  v3.0  –  CAPABILITY-BASED EDITION", "═")
    logger.info(f"  Run started  : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f"  Input sheet  : {cfg['input_sheet']}")
    logger.info(f"  Report root  : {cfg['report_root']}")

    input_sheet    = Path(cfg["input_sheet"])
    report_root    = Path(cfg["report_root"])
    converted_root = report_root / "ConvertedCSVs"
    ensure_dir(report_root)
    ensure_dir(converted_root)

    if not input_sheet.exists():
        logger.error(f"❌ Input sheet not found: {input_sheet}")
        raise FileNotFoundError(f"Input sheet not found: {input_sheet}")

    # ── parse InputSheet ──────────────────────────────────────────────────────
    logger.info("  Parsing InputSheet …")
    xl = pd.ExcelFile(input_sheet, engine="openpyxl")

    input_sheet_name = (
        "InputSheet _Data_Comparison"
        if "InputSheet _Data_Comparison" in xl.sheet_names
        else _find_sheet_by_hint(xl, "input", "comparison", fallback_first=True)
    )
    tol_sheet_name = (
        "Numerical Tolerance"
        if "Numerical Tolerance" in xl.sheet_names
        else _find_sheet_by_hint(xl, "tolerance", "numeric", fallback_first=False)
    )

    logger.info(f"  Config sheet   : {input_sheet_name}")
    logger.info(f"  Tolerance sheet: {tol_sheet_name or '(none found)'}")

    cfg_df  = xl.parse(input_sheet_name)
    tol_df  = xl.parse(tol_sheet_name) if tol_sheet_name else pd.DataFrame()
    tol_map = build_tolerance_map(tol_df)

    colmap   = validate_config_sheet(cfg_df)
    key_cols = extract_key_columns(cfg_df)

    col_run = colmap.get("run")
    active_rows = [
        row for _, row in cfg_df.iterrows()
        if str(row.get(col_run, "")).strip().lower() in ("yes", "y", "true", "1")
    ]
    logger.info(f"  Active batches : {len(active_rows)} of {len(cfg_df)} rows")

    # ── capability config from YAML ───────────────────────────────────────────
    caps_cfg        = cfg.get("capabilities",        {})
    alert_rules_cfg = cfg.get("alert_rules",         [])
    dq_checks_cfg   = cfg.get("data_quality_checks", {})
    plugins_cfg     = cfg.get("plugins",             {})

    banner(f"STARTING  {len(active_rows)}  BATCH(ES)", "─")

    summaries:   List[Dict] = []
    attachments: List[Path] = []

    for batch_num, row in enumerate(active_rows, start=1):
        (
            base_path_str,
            prod_name,
            dev_name,
            result_nm,
            sheet_name,
            keys,
            include_pass,
            ignore_fields,
        ) = parse_batch_row(row, colmap, key_cols)

        batch_label = f"Batch {batch_num}/{len(active_rows)}: {result_nm}"
        banner(batch_label)
        t_batch = time.perf_counter()

        try:
            prod_file = Path(base_path_str) / prod_name
            dev_file  = Path(base_path_str) / dev_name

            logger.info(f"  PROD: {prod_file}")
            logger.info(f"  DEV : {dev_file}")

            if not prod_file.exists():
                raise FileNotFoundError(f"PROD file not found: {prod_file}")
            if not dev_file.exists():
                raise FileNotFoundError(f"DEV  file not found: {dev_file}")

            # ── normalise files to CSV ────────────────────────────────────────
            prod_csv = load_any_to_csv(
                prod_file, converted_root, sheet_name=sheet_name
            )
            dev_csv = load_any_to_csv(
                dev_file, converted_root, sheet_name=sheet_name
            )

            logger.info(
                f"  Keys: {keys or '(none – row-order fallback)'}  "
                f"include_pass={include_pass}  ignore={ignore_fields}"
            )

            # ── build context ─────────────────────────────────────────────────
            # Merge YAML capability flags with any per-batch overrides (none here)
            context = make_context(
                prod_csv_path=prod_csv,
                dev_csv_path=dev_csv,
                prod_name=prod_name,
                dev_name=dev_name,
                result_name=result_nm,
                report_root=report_root,
                include_pass_report=include_pass,
                keys=keys,
                ignore_fields=ignore_fields,
                tol_map=tol_map,
                capabilities_cfg=caps_cfg,
                alert_rules=alert_rules_cfg,
                data_quality_checks=dq_checks_cfg,
            )
            # Inject plugins config if present
            if plugins_cfg:
                context["config"]["plugins"] = plugins_cfg

            # ── run capability pipeline ───────────────────────────────────────
            banner(f"  PIPELINE: {result_nm}", "·")
            context = registry.run_pipeline(context)

            # ── write workbook ────────────────────────────────────────────────
            out_xlsx = build_report(context)
            if out_xlsx:
                context["report_path"] = str(out_xlsx)
                attachments.append(out_xlsx)

            elapsed = time.perf_counter() - t_batch
            context["elapsed_seconds"] = elapsed

            summary = _context_to_summary(context, elapsed)
            summaries.append(summary)

            logger.info(
                f"  ✅ Batch '{result_nm}' complete  [{elapsed:.1f}s]"
            )

        except Exception as exc:
            # Per-batch isolation – one failure never stops remaining batches
            elapsed = time.perf_counter() - t_batch
            logger.error(
                f"  ❌ Batch {batch_num} FAILED: {exc}", exc_info=True
            )
            summaries.append(
                _empty_error_summary(result_nm, prod_name, dev_name, exc)
            )

    # ── final outputs ─────────────────────────────────────────────────────────
    total_elapsed = time.perf_counter() - run_start
    _print_console_summary(summaries)

    if summaries:
        banner("WRITING FINAL OUTPUTS")
        final_html = write_final_html(summaries, report_root, total_elapsed)
        write_json_audit(summaries, report_root, total_elapsed)
        attachments.append(final_html)

        subject = (
            f"{cfg['email_subject_prefix']} – "
            f"{datetime.now():%Y-%m-%d}  "
            f"({len(summaries)} batches)"
        )
        send_email(
            email_to=cfg["email_to"],
            subject=subject,
            html_body_path=final_html,
            attachments=attachments,
            smtp_host=cfg.get("smtp_host", ""),
            smtp_port=int(cfg.get("smtp_port", 587)),
            smtp_from=cfg.get("smtp_from", ""),
            smtp_user=cfg.get("smtp_user", ""),
            smtp_pass=cfg.get("smtp_pass", ""),
        )
    else:
        logger.warning("No batches completed – nothing to report.")

    logger.info(
        f"  Total run time: {total_elapsed:.1f}s  "
        f"({math.ceil(total_elapsed / 60)} min)"
    )
    banner("DATA COMPARATOR  COMPLETE", "═")
    return summaries
