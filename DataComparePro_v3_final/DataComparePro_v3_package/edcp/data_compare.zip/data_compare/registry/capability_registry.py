# -*- coding: utf-8 -*-
"""
data_compare.registry.capability_registry
───────────────────────────────────────────
Capability Registry

Centralised registry that:
  1. Holds all built-in capabilities mapped by name.
  2. Allows dynamic registration of third-party capabilities at runtime.
  3. Builds the ordered execution pipeline based on the enabled-flags in context.
  4. Provides a run_pipeline() entry point used by the orchestrator.

The registry enforces the capability execution order:
    tolerance → schema → duplicate → comparison → data_quality → audit → alerts → plugins

This order ensures:
  - tolerance rules are resolved before comparison uses them
  - schema diffs are computed before comparison annotates them with counts
  - duplicate alignment is ready before comparison builds the index
  - data_quality runs after data is loaded by comparison
  - audit runs after all work is done
  - alerts evaluate final metrics
  - plugins run last and have access to everything

Usage
-----
    from data_compare.registry.capability_registry import CapabilityRegistry

    registry = CapabilityRegistry()
    context  = make_context(...)
    context  = registry.run_pipeline(context)

Dynamic registration of a custom capability:
    from my_project.capabilities.custom import MyCapability
    registry.register(MyCapability())
    # It will be appended after the built-in capabilities
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from data_compare.capabilities.base import BaseCapability
from data_compare.capabilities.alerts.alerts_capability import AlertsCapability
from data_compare.capabilities.audit.audit_capability import AuditCapability
from data_compare.capabilities.comparison.comparison_capability import (
    ComparisonCapability,
)
from data_compare.capabilities.data_quality.data_quality_capability import (
    DataQualityCapability,
)
from data_compare.capabilities.duplicate.duplicate_capability import (
    DuplicateCapability,
)
from data_compare.capabilities.plugins.plugin_capability import PluginCapability
from data_compare.capabilities.schema.schema_capability import SchemaCapability
from data_compare.capabilities.tolerance.tolerance_capability import (
    ToleranceCapability,
)
from data_compare.utils.logger import get_logger, banner

logger = get_logger(__name__)

# ── Default execution order for built-in capabilities ─────────────────────────
# ORDER RATIONALE:
#   tolerance  – resolves tol_for_pair; needs prod/dev names only (no data needed)
#   duplicate  – detects dups and builds _SEQ_ alignment; needs prod_df/dev_df
#                BUT comparison loads the data AND calls dup logic internally.
#                DuplicateCapability here enriches duplicates_summary for the report.
#   comparison – core engine: loads data, calls tolerance/dup logic, compares values.
#                Reads tol_for_pair from context (set by ToleranceCapability above).
#                Reads prod_df/dev_df from context if already set, else loads them.
#   schema     – annotates schema diff with non-empty counts using prod_common/dev_common.
#   data_quality– reads prod_df/dev_df.
#   audit      – materialises event trail.
#   alerts     – evaluates final metrics.
#   plugins    – user code runs last.
_DEFAULT_ORDER = [
    "tolerance",
    "comparison",
    "duplicate",
    "schema",
    "data_quality",
    "audit",
    "alerts",
    "plugins",
]


class CapabilityRegistry:
    """
    Registry of all capabilities available to the framework.

    Built-in capabilities are registered automatically at construction.
    Third-party capabilities can be added via register().

    The execution order of built-in capabilities is fixed (see _DEFAULT_ORDER).
    Dynamically registered capabilities are appended after the built-ins in
    registration order.
    """

    def __init__(self) -> None:
        # Ordered dict: name → capability instance
        self._builtin: Dict[str, BaseCapability] = {}
        self._custom:  Dict[str, BaseCapability] = {}
        self._register_builtins()

    # ── registration ─────────────────────────────────────────────────────────

    def _register_builtins(self) -> None:
        """Instantiate and register all built-in capabilities."""
        builtins: List[BaseCapability] = [
            ToleranceCapability(),
            SchemaCapability(),
            DuplicateCapability(),
            ComparisonCapability(),
            DataQualityCapability(),
            AuditCapability(),
            AlertsCapability(),
            PluginCapability(),
        ]
        for cap in builtins:
            self._builtin[cap.NAME] = cap
        logger.debug(
            f"  [registry] Built-in capabilities registered: "
            f"{list(self._builtin.keys())}"
        )

    def register(self, capability: BaseCapability) -> None:
        """
        Register a custom capability.

        The capability will be executed after all built-in capabilities,
        in the order it was registered.  If a capability with the same NAME
        is already registered (built-in or custom), it is replaced.

        Parameters
        ----------
        capability : BaseCapability
            An instantiated capability object.
        """
        if not isinstance(capability, BaseCapability):
            raise TypeError(
                f"Expected a BaseCapability subclass, got {type(capability)}"
            )
        if capability.NAME in self._builtin:
            logger.warning(
                f"  [registry] Replacing built-in capability '{capability.NAME}' "
                f"with custom implementation"
            )
            self._builtin[capability.NAME] = capability
        else:
            self._custom[capability.NAME] = capability
            logger.info(
                f"  [registry] Custom capability '{capability.NAME}' registered"
            )

    def unregister(self, name: str) -> None:
        """Remove a capability by name (built-in or custom)."""
        removed = False
        if name in self._builtin:
            del self._builtin[name]
            removed = True
        if name in self._custom:
            del self._custom[name]
            removed = True
        if removed:
            logger.info(f"  [registry] Capability '{name}' unregistered")
        else:
            logger.warning(f"  [registry] Capability '{name}' not found")

    def list_capabilities(self) -> List[str]:
        """Return all registered capability names in execution order."""
        # Built-ins in fixed order, then customs in registration order
        ordered_builtins = [
            n for n in _DEFAULT_ORDER if n in self._builtin
        ]
        # Built-ins not in _DEFAULT_ORDER (shouldn't happen, but safe)
        extra_builtins = [
            n for n in self._builtin if n not in _DEFAULT_ORDER
        ]
        customs = list(self._custom.keys())
        return ordered_builtins + extra_builtins + customs

    def get(self, name: str) -> Optional[BaseCapability]:
        """Return a registered capability by name, or None."""
        return self._builtin.get(name) or self._custom.get(name)

    # ── pipeline execution ────────────────────────────────────────────────────

    def run_pipeline(
        self,
        context: Dict[str, Any],
        override_order: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Execute all enabled capabilities in order against *context*.

        Parameters
        ----------
        context : dict
            Fully initialised run context (see data_compare.context.run_context).
        override_order : list[str] | None
            If provided, execute only the named capabilities in that exact order.
            Useful for testing individual capabilities or building custom pipelines.

        Returns
        -------
        dict
            The updated context after all capabilities have run.
        """
        execution_order = override_order if override_order else self.list_capabilities()

        enabled_caps = [
            name for name in execution_order
            if context.get("config", {}).get("capabilities", {}).get(name, True)
        ]
        disabled_caps = [
            name for name in execution_order
            if name not in enabled_caps
        ]

        logger.info(
            f"  [registry] Pipeline: {len(enabled_caps)} enabled, "
            f"{len(disabled_caps)} disabled"
        )
        if disabled_caps:
            logger.info(f"  [registry] Disabled: {disabled_caps}")

        for name in execution_order:
            cap = self.get(name)
            if cap is None:
                logger.warning(
                    f"  [registry] Capability '{name}' listed but not registered – skipped"
                )
                continue
            # BaseCapability.run() checks is_enabled internally and logs SKIPPED
            context = cap.run(context)

        return context


# ── module-level singleton ────────────────────────────────────────────────────

#: Default shared registry instance.  Import and use this in most cases.
default_registry = CapabilityRegistry()
