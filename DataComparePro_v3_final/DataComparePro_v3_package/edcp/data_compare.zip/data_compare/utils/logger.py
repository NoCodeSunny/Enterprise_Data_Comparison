# -*- coding: utf-8 -*-
"""
data_compare.utils.logger
─────────────────────────
Centralised logging configuration shared by every module in the package.

All modules obtain the logger via:
    from data_compare.utils.logger import get_logger
    logger = get_logger(__name__)

The root logger "DataComparator" is configured once when this module is first
imported.  Subsequent calls to get_logger() return child loggers that inherit
its level and handlers.  This design is fully compatible with PySpark workers
because it does not rely on any Windows-specific sink.
"""

import logging
import sys
from typing import Optional

# ── format constants ──────────────────────────────────────────────────────────
_LOG_FMT  = "%(asctime)s │ %(levelname)-8s │ %(name)s │ %(message)s"
_DATE_FMT = "%Y-%m-%d %H:%M:%S"
_ROOT_NAME = "DataComparator"

# ── internal flag – only configure once ───────────────────────────────────────
_configured = False


def configure_logging(level: int = logging.DEBUG) -> None:
    """
    Configure the root DataComparator logger.  Safe to call multiple times;
    only acts on the first call per process.
    """
    global _configured
    if _configured:
        return

    root = logging.getLogger(_ROOT_NAME)
    root.setLevel(level)

    if not root.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(level)
        formatter = logging.Formatter(fmt=_LOG_FMT, datefmt=_DATE_FMT)
        handler.setFormatter(formatter)
        root.addHandler(handler)

    # Prevent duplicate messages propagating to the Python root logger
    root.propagate = False
    _configured = True


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """
    Return a child logger of DataComparator.

    Parameters
    ----------
    name : str, optional
        Usually __name__ of the calling module.
        If None, returns the root DataComparator logger directly.
    """
    configure_logging()  # no-op if already done
    if name is None or name == _ROOT_NAME:
        return logging.getLogger(_ROOT_NAME)
    # Ensure name is a child of the root logger
    if not name.startswith(_ROOT_NAME):
        child_name = f"{_ROOT_NAME}.{name}"
    else:
        child_name = name
    return logging.getLogger(child_name)


# ── convenience helpers (banner + progress bar) ───────────────────────────────

def banner(title: str, char: str = "─", width: int = 72) -> None:
    """Emit a visible section banner at INFO level."""
    lg = get_logger()
    pad = max(0, width - len(title) - 4)
    left  = pad // 2
    right = pad - left
    lg.info(char * left + "  " + title + "  " + char * right)


def progress(current: int, total: int, label: str = "") -> None:
    """Emit a progress bar at DEBUG level."""
    lg = get_logger()
    pct      = int(100 * current / total) if total else 0
    bar_len  = 30
    filled   = int(bar_len * current / total) if total else 0
    bar      = "█" * filled + "░" * (bar_len - filled)
    msg      = f"[{bar}] {pct:3d}%  {current}/{total}"
    if label:
        msg += f"  {label}"
    lg.debug(msg)
